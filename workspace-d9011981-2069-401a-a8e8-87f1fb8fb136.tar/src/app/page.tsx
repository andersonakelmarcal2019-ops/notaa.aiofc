'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Eye, EyeOff, Mail, Lock, Music } from 'lucide-react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isDark, setIsDark] = useState(true)

  const handleAutoFill = () => {
    setEmail('notaaicliente1284@notaai.site')
    setPassword('cliente1284')
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    // Simulação de login - em produção, isso seria uma chamada de API
    setTimeout(() => {
      // Redirecionar para a área de membros
      window.location.href = '/membros'
    }, 1000)
  }

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-blue-50 via-white to-gray-100'} flex items-center justify-center p-4`}>
      <div className={`absolute inset-0 ${isDark ? 'bg-black/20' : 'bg-white/40'} backdrop-blur-sm`}></div>
      
      <Card className={`w-full max-w-md relative z-10 ${isDark ? 'border-gray-700 bg-gray-800/90' : 'border-gray-300 bg-white/90'} backdrop-blur-md shadow-2xl`}>
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full">
              <Music className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Faça seu Login</CardTitle>
          <CardDescription className={isDark ? 'text-gray-400' : 'text-gray-600'}>
            Acesse sua área de membros e desbloqueie todo o conteúdo
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className={`${isDark ? 'text-gray-300' : 'text-gray-700'} flex items-center gap-2`}>
                <Mail className="w-4 h-4" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Seu email"
                className={isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-yellow-500 focus:ring-yellow-500' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-yellow-500 focus:ring-yellow-500'}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className={`${isDark ? 'text-gray-300' : 'text-gray-700'} flex items-center gap-2`}>
                <Lock className="w-4 h-4" />
                Senha
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Sua senha"
                  className={isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400 focus:border-yellow-500 focus:ring-yellow-500 pr-10' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500 focus:border-yellow-500 focus:ring-yellow-500 pr-10'}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400 hover:text-white' : 'text-gray-500 hover:text-gray-700'} transition-colors`}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white font-semibold py-3 rounded-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
              disabled={isLoading}
            >
              {isLoading ? 'Entrando...' : 'Entrar na Área de Membros'}
            </Button>
          </form>
          
          <div className="space-y-4 pt-4 border-t border-gray-700">
            <Button
              onClick={handleAutoFill}
              variant="outline"
              className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'} transition-all duration-200`}
            >
              Preencher Automaticamente
            </Button>
            
            <div className={`${isDark ? 'bg-gray-700/30' : 'bg-gray-100'} p-4 rounded-lg space-y-2`}>
              <p className={`text-sm font-semibold ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Credenciais de acesso:</p>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                <span className="font-medium">Email:</span> notaaicliente1284@notaai.site
              </p>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                <span className="font-medium">Senha:</span> cliente1284
              </p>
            </div>
            
            <div className="text-center">
              <a
                href="#"
                className={`text-sm ${isDark ? 'text-yellow-500 hover:text-yellow-400' : 'text-yellow-600 hover:text-yellow-700'} transition-colors underline`}
              >
                Problemas para acessar? Entre em contato
              </a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}