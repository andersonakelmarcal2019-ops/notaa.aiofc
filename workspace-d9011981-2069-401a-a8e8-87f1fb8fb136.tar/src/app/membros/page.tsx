'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useTheme } from '@/hooks/use-theme'
import { 
  Settings, 
  ShoppingBag, 
  Music, 
  Search, 
  Filter, 
  Star, 
  Download, 
  Play, 
  Moon, 
  Sun,
  HelpCircle,
  FileText,
  Heart,
  Clock,
  User,
  LogOut,
  Lock,
  ChevronDown,
  ChevronUp
} from 'lucide-react'

// Lista das músicas separadas por categoria
const musicasPorCategoria = {
  iniciante: [
    { id: 1, nome: "🔹 Someone Like You – Adele", categoria: "Iniciante" },
    { id: 2, nome: "🔹 All of Me – John Legend", categoria: "Iniciante" },
    { id: 3, nome: "🔹 Perfect – Ed Sheeran", categoria: "Iniciante" },
    { id: 4, nome: "🔹 Let It Be – The Beatles", categoria: "Iniciante" },
    { id: 5, nome: "🔹 Yesterday – The Beatles", categoria: "Iniciante" },
    { id: 6, nome: "🔹 Stand By Me – Ben E. King", categoria: "Iniciante" },
    { id: 7, nome: "🔹 Can't Help Falling in Love – Elvis Presley", categoria: "Iniciante" },
    { id: 8, nome: "🔹 Love Me Tender – Elvis Presley", categoria: "Iniciante" },
    { id: 9, nome: "🔹 Imagine – John Lennon", categoria: "Iniciante" },
    { id: 10, nome: "🔹 Hallelujah – Leonard Cohen", categoria: "Iniciante" },
    { id: 11, nome: "🔹 Clocks – Coldplay (versão simplificada)", categoria: "Iniciante" },
    { id: 12, nome: "🔹 Fix You – Coldplay", categoria: "Iniciante" },
    { id: 13, nome: "🔹 Mad World – Gary Jules", categoria: "Iniciante" },
    { id: 14, nome: "🔹 Stay – Rihanna", categoria: "Iniciante" },
    { id: 15, nome: "🔹 Shallow – Lady Gaga & Bradley Cooper", categoria: "Iniciante" },
    { id: 16, nome: "🔹 Say You Won't Let Go – James Arthur", categoria: "Iniciante" },
    { id: 17, nome: "🔹 Aquarela – Toquinho", categoria: "Iniciante" },
    { id: 18, nome: "🔹 Pra Você Guardei o Amor – Nando Reis", categoria: "Iniciante" },
    { id: 19, nome: "🔹 Asa Branca – Luiz Gonzaga", categoria: "Iniciante" },
    { id: 20, nome: "🔹 Garota de Ipanema – Tom Jobim", categoria: "Iniciante" }
  ],
  intermediario: [
    { id: 21, nome: "🎼 Für Elise – Beethoven", categoria: "Intermediário" },
    { id: 22, nome: "🎼 Clair de Lune – Debussy", categoria: "Intermediário" },
    { id: 23, nome: "🎼 Moonlight Sonata – Beethoven", categoria: "Intermediário" },
    { id: 24, nome: "🎼 Canon in D – Pachelbel", categoria: "Intermediário" },
    { id: 25, nome: "🎼 Nocturne Op.9 No.2 – Chopin", categoria: "Intermediário" },
    { id: 26, nome: "🎼 The Entertainer – Scott Joplin", categoria: "Intermediário" },
    { id: 27, nome: "🎼 Gymnopédie No.1 – Erik Satie", categoria: "Intermediário" },
    { id: 28, nome: "🎼 Prelude in C Major – Bach", categoria: "Intermediário" },
    { id: 29, nome: "🎼 Ave Maria – Schubert", categoria: "Intermediário" },
    { id: 30, nome: "🎼 Rondo Alla Turca – Mozart", categoria: "Intermediário" },
    { id: 31, nome: "🎼 Swan Lake Theme – Tchaikovsky", categoria: "Intermediário" },
    { id: 32, nome: "🎼 Hungarian Rhapsody No.2 – Liszt", categoria: "Intermediário" },
    { id: 33, nome: "🎼 Liebestraum No.3 – Liszt", categoria: "Intermediário" },
    { id: 34, nome: "🎼 Toccata and Fugue in D minor – Bach", categoria: "Intermediário" },
    { id: 35, nome: "🎼 Spring (Four Seasons) – Vivaldi", categoria: "Intermediário" },
    { id: 36, nome: "🎼 La Campanella – Liszt", categoria: "Intermediário" },
    { id: 37, nome: "🎼 Dance of the Sugar Plum Fairy – Tchaikovsky", categoria: "Intermediário" },
    { id: 38, nome: "🎼 Air on the G String – Bach", categoria: "Intermediário" },
    { id: 39, nome: "🎼 Arabesque No.1 – Debussy", categoria: "Intermediário" },
    { id: 40, nome: "🎼 Méditation – Massenet", categoria: "Intermediário" },
    { id: 41, nome: "💭 Dream On – Aerosmith", categoria: "Intermediário" },
    { id: 42, nome: "💭 Hey Jude – The Beatles", categoria: "Intermediário" },
    { id: 43, nome: "💭 Sweet Child O' Mine – Guns N' Roses", categoria: "Intermediário" },
    { id: 44, nome: "💭 We Are the Champions – Queen", categoria: "Intermediário" },
    { id: 45, nome: "💭 Come Together – The Beatles", categoria: "Intermediário" },
    { id: 46, nome: "💭 Tiny Dancer – Elton John", categoria: "Intermediário" },
    { id: 47, nome: "💭 Rocket Man – Elton John", categoria: "Intermediário" },
    { id: 48, nome: "💭 Highway to Hell – AC/DC", categoria: "Intermediário" },
    { id: 49, nome: "💭 Under the Bridge – Red Hot Chili Peppers", categoria: "Intermediário" },
    { id: 50, nome: "🌊 River Flows in You – Yiruma", categoria: "Intermediário" },
    { id: 51, nome: "🌊 Comptine d'un autre été – Amélie", categoria: "Intermediário" },
    { id: 52, nome: "🪐 Interstellar Main Theme – Hans Zimmer", categoria: "Intermediário" },
    { id: 53, nome: "🏴‍☠️ Pirates of the Caribbean – Hans Zimmer", categoria: "Intermediário" },
    { id: 54, nome: "🛡️ The Avengers Theme – Alan Silvestri", categoria: "Intermediário" },
    { id: 55, nome: "🌟 City of Stars – La La Land", categoria: "Intermediário" },
    { id: 56, nome: "🧙 Hedwig's Theme – Harry Potter", categoria: "Intermediário" },
    { id: 57, nome: "❤️ My Heart Will Go On – Titanic", categoria: "Intermediário" },
    { id: 58, nome: "📦 The Notebook Theme", categoria: "Intermediário" },
    { id: 59, nome: "💭 Requiem for a Dream – Clint Mansell", categoria: "Intermediário" },
    { id: 60, nome: "🪐 Time – Inception", categoria: "Intermediário" },
    { id: 61, nome: "🏴‍☠️ He's a Pirate – Pirates of the Caribbean", categoria: "Intermediário" },
    { id: 62, nome: "🦖 Jurassic Park Theme – John Williams", categoria: "Intermediário" },
    { id: 63, nome: "📦 Schindler's List Theme – John Williams", categoria: "Intermediário" },
    { id: 64, nome: "📦 Spirit in the Sky – One Summer's Day", categoria: "Intermediário" },
    { id: 65, nome: "🎵 Thinking Out Loud – Ed Sheeran", categoria: "Intermediário" },
    { id: 66, nome: "🎵 Photograph – Ed Sheeran", categoria: "Intermediário" },
    { id: 67, nome: "🎵 Shape of You – Ed Sheeran", categoria: "Intermediário" },
    { id: 68, nome: "🎵 Castle on the Hill – Taylor Swift", categoria: "Intermediário" },
    { id: 69, nome: "🎵 Someone You Loved – Adele", categoria: "Intermediário" },
    { id: 70, nome: "🎵 Rolling in the Deep – Adele", categoria: "Intermediário" },
    { id: 71, nome: "🎵 Set Fire to the Rain – Adele", categoria: "Intermediário" },
    { id: 72, nome: "🎵 Hello – Adele", categoria: "Intermediário" },
    { id: 73, nome: "🎵 Easy On Me – Adele", categoria: "Intermediário" },
    { id: 74, nome: "🎵 Love Me Like You Do – Ellie Goulding", categoria: "Intermediário" },
    { id: 75, nome: "🎵 Just the Way You Are – Bruno Mars", categoria: "Intermediário" },
    { id: 76, nome: "🎵 Jealous – Labrinth", categoria: "Intermediário" },
    { id: 77, nome: "🎵 Too Good at Goodbyes – Sam Smith", categoria: "Intermediário" },
    { id: 78, nome: "🎵 Stay With Me – Sam Smith", categoria: "Intermediário" },
    { id: 79, nome: "🎵 Shallow – Lady Gaga & Bradley Cooper", categoria: "Intermediário" },
    { id: 80, nome: "🎵 Always Remember Us This Way – Lady Gaga", categoria: "Intermediário" }
  ],
  brasileiras: [
    { id: 81, nome: "🎨 Aquarela – Toquinho", categoria: "Brasileiras" },
    { id: 82, nome: "📦 Evidências – Chitãozinho & Xororó", categoria: "Brasileiras" },
    { id: 83, nome: "📦 Trem Bala – Ana Vilela", categoria: "Brasileiras" },
    { id: 84, nome: "📦 O Mundo é um Moinho – Cartola", categoria: "Brasileiras" },
    { id: 85, nome: "💌 Pra Você Guardei o Amor – Nando Reis", categoria: "Brasileiras" },
    { id: 86, nome: "📦 Asa Branca – Luiz Gonzaga", categoria: "Brasileiras" },
    { id: 87, nome: "📦 Azul da Cor do Mar – Tim Maia", categoria: "Brasileiras" },
    { id: 88, nome: "💌 Pra Você Guardei o Amor – Nando Reis", categoria: "Brasileiras" },
    { id: 89, nome: "📦 O Leãozinho – Caetano Veloso", categoria: "Brasileiras" },
    { id: 90, nome: "📦 Chega de Saudade – João Gilberto", categoria: "Brasileiras" },
    { id: 91, nome: "🎨 Aquarela – Toquinho", categoria: "Brasileiras" },
    { id: 92, nome: "📦 Evidências – Chitãozinho & Xororó", categoria: "Brasileiras" },
    { id: 93, nome: "📦 Trem Bala – Ana Vilela", categoria: "Brasileiras" },
    { id: 94, nome: "📦 O Mundo é um Moinho – Cartola", categoria: "Brasileiras" },
    { id: 95, nome: "💌 Pra Você Guardei o Amor – Nando Reis", categoria: "Brasileiras" },
    { id: 96, nome: "📦 Asa Branca – Luiz Gonzaga", categoria: "Brasileiras" },
    { id: 97, nome: "📦 Azul da Cor do Mar – Tim Maia", categoria: "Brasileiras" },
    { id: 98, nome: "💌 Pra Você Guardei o Amor – Nando Reis", categoria: "Brasileiras" },
    { id: 99, nome: "📦 O Leãozinho – Caetano Veloso", categoria: "Brasileiras" },
    { id: 100, nome: "📦 Chega de Saudade – João Gilberto", categoria: "Brasileiras" }
  ]
}

// Componente de card de música
function MusicCard({ musica, isFavorite, onToggleFavorite, isDark }: { 
  musica: typeof musicasPorCategoria.iniciante[0]; 
  isFavorite: boolean; 
  onToggleFavorite: () => void;
  isDark: boolean;
}) {
  return (
    <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700 hover:border-yellow-500' : 'bg-white/50 border-gray-300 hover:border-yellow-500'} transition-all duration-200 hover:shadow-lg`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <h3 className={`font-medium text-sm flex-1 mr-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>{musica.nome}</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleFavorite}
            className={`${isDark ? 'text-gray-400 hover:text-yellow-500' : 'text-gray-600 hover:text-yellow-500'} p-1 h-auto`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
          </Button>
        </div>
        
        <div className="flex items-center gap-2 mb-3">
          <Badge variant="secondary" className={`text-xs ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}>
            {musica.categoria}
          </Badge>
        </div>
        
        <div className="flex gap-2">
          <Button
            size="sm"
            className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-xs"
            onClick={() => window.location.href = `/video-aula/${musica.id}`}
          >
            <Play className="w-3 h-3 mr-1" />
            Ver Vídeo
          </Button>
          <Button
            variant="outline"
            size="sm"
            className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'} text-xs`}
          >
            <Download className="w-3 h-3" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

// Componente de categoria (accordion)
function CategoriaAccordion({ 
  categoria, 
  musicas, 
  isFavorite, 
  onToggleFavorite, 
  isDark, 
  isOpen, 
  onToggle 
}: {
  categoria: string;
  musicas: typeof musicasPorCategoria.iniciante;
  isFavorite: (id: number) => boolean;
  onToggleFavorite: (id: number) => void;
  isDark: boolean;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} mb-4`}>
      <CardHeader 
        className="cursor-pointer"
        onClick={onToggle}
      >
        <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'} flex items-center justify-between`}>
          <span>{categoria}</span>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className={`text-xs ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}>
              {musicas.length} músicas
            </Badge>
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </CardTitle>
      </CardHeader>
      
      {isOpen && (
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-h-96 overflow-y-auto">
            {musicas.map(musica => (
              <MusicCard 
                key={musica.id} 
                musica={musica}
                isFavorite={isFavorite(musica.id)}
                isDark={isDark}
                onToggleFavorite={() => onToggleFavorite(musica.id)}
              />
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  )
}

export default function MemberArea() {
  const [searchTerm, setSearchTerm] = useState('')
  const [favorites, setFavorites] = useState<number[]>([])
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['iniciante'])
  const { isDark, setIsDark } = useTheme()

  const allMusicas = [
    ...musicasPorCategoria.iniciante,
    ...musicasPorCategoria.intermediario,
    ...musicasPorCategoria.brasileiras
  ]

  const musicasFiltradas = allMusicas.filter(musica => {
    const matchesSearch = musica.nome.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesSearch
  })

  const handleToggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) 
        ? prev.filter(favId => favId !== id)
        : [...prev, id]
    )
  }

  const handleToggleCategory = (categoria: string) => {
    setExpandedCategories(prev => 
      prev.includes(categoria) 
        ? prev.filter(cat => cat !== categoria)
        : [...prev, categoria]
    )
  }

  const isFavorite = (id: number) => favorites.includes(id)

  const handleLogout = () => {
    window.location.href = '/'
  }

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-gray-100 via-gray-50 to-gray-100'}`}>
      {/* Header */}
      <header className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-200'} backdrop-blur-md border-b sticky top-0 z-50`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>200 Músicas para Piano</h1>
                <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Área de Membros</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsDark(!isDark)}
                className={`${isDark ? 'text-gray-400 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
              
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Olá, Aluno</span>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className={`${isDark ? 'text-gray-400 hover:text-red-400' : 'text-gray-600 hover:text-red-600'}`}
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs defaultValue="musicas" className="w-full">
          <TabsList className={`grid w-full grid-cols-3 ${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} border mb-6`}>
            <TabsTrigger value="musicas" className={`data-[state=active]:bg-yellow-500 data-[state=active]:text-white ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              <Music className="w-4 h-4 mr-2" />
              Músicas
            </TabsTrigger>
            <TabsTrigger value="loja" className={`data-[state=active]:bg-yellow-500 data-[state=active]:text-white ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              <ShoppingBag className="w-4 h-4 mr-2" />
              Loja
            </TabsTrigger>
            <TabsTrigger value="configuracoes" className={`data-[state=active]:bg-yellow-500 data-[state=active]:text-white ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              <Settings className="w-4 h-4 mr-2" />
              Configurações
            </TabsTrigger>
          </TabsList>

          {/* Aba Músicas */}
          <TabsContent value="musicas" className="space-y-6">
            {/* Busca */}
            <div className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} rounded-lg p-4 border mb-6`}>
              <div className="relative">
                <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'} w-4 h-4`} />
                <Input
                  placeholder="Buscar músicas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`pl-10 w-full ${isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500'}`}
                />
              </div>
            </div>

            {/* Categorias em Accordion */}
            <div className="space-y-4">
              <CategoriaAccordion
                categoria="🎹 1️⃣ INICIANTE"
                musicas={musicasPorCategoria.iniciante}
                isFavorite={isFavorite}
                onToggleFavorite={handleToggleFavorite}
                isDark={isDark}
                isOpen={expandedCategories.includes('iniciante')}
                onToggle={() => handleToggleCategory('iniciante')}
              />

              <CategoriaAccordion
                categoria="🎼 2️⃣ INTERMEDIÁRIO"
                musicas={musicasPorCategoria.intermediario}
                isFavorite={isFavorite}
                onToggleFavorite={handleToggleFavorite}
                isDark={isDark}
                isOpen={expandedCategories.includes('intermediario')}
                onToggle={() => handleToggleCategory('intermediario')}
              />

              <CategoriaAccordion
                categoria="🇧🇷 3️⃣ BR / BRASILEIRAS"
                musicas={musicasPorCategoria.brasileiras}
                isFavorite={isFavorite}
                onToggleFavorite={handleToggleFavorite}
                isDark={isDark}
                isOpen={expandedCategories.includes('brasileiras')}
                onToggle={() => handleToggleCategory('brasileiras')}
              />
            </div>

            {/* Estatísticas */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">{allMusicas.length}</div>
                  <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Total de Músicas</div>
                </CardContent>
              </Card>
              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {musicasPorCategoria.iniciante.length}
                  </div>
                  <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Iniciante</div>
                </CardContent>
              </Card>
              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-500">
                    {musicasPorCategoria.intermediario.length}
                  </div>
                  <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Intermediário</div>
                </CardContent>
              </Card>
              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardContent className="p-4 text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {musicasPorCategoria.brasileiras.length}
                  </div>
                  <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Brasileiras</div>
                </CardContent>
              </Card>
            </div>

            {/* Favoritos */}
            {favorites.length > 0 && (
              <div className="space-y-4">
                <h2 className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'} mb-4`}>
                  ❤️ Músicas Favoritas ({favorites.length})
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {allMusicas
                    .filter(musica => favorites.includes(musica.id))
                    .map(musica => (
                      <MusicCard 
                        key={musica.id} 
                        musica={musica}
                        isFavorite={isFavorite(musica.id)}
                        isDark={isDark}
                        onToggleFavorite={() => handleToggleFavorite(musica.id)}
                      />
                    ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Aba Loja */}
          <TabsContent value="loja" className="space-y-6">
            <div className="text-center py-12">
              <ShoppingBag className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
              <h2 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-gray-900'}`}>Loja de Produtos</h2>
              <p className={`mb-8 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Em breve novos produtos e upgrades disponíveis</p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
                <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700 hover:border-yellow-500' : 'bg-white/50 border-gray-300 hover:border-yellow-500'} transition-all`}>
                  <CardHeader>
                    <div className="w-full h-32 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg mb-4"></div>
                    <CardTitle className={isDark ? 'text-white' : 'text-gray-900'}>Pacote Premium</CardTitle>
                    <CardDescription className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                      Acesso vitalício a todos os conteúdos futuros
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-yellow-500 mb-4">R$ 197,00</div>
                    <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                      Comprar Agora
                    </Button>
                  </CardContent>
                </Card>

                <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700 hover:border-yellow-500' : 'bg-white/50 border-gray-300 hover:border-yellow-500'} transition-all`}>
                  <CardHeader>
                    <div className="w-full h-32 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg mb-4"></div>
                    <CardTitle className={isDark ? 'text-white' : 'text-gray-900'}>Aulas Particulares</CardTitle>
                    <CardDescription className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                      Aulas individuais com professores especializados
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-500 mb-4">R$ 97,00/mês</div>
                    <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                      Assinar
                    </Button>
                  </CardContent>
                </Card>

                <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700 hover:border-yellow-500' : 'bg-white/50 border-gray-300 hover:border-yellow-500'} transition-all`}>
                  <CardHeader>
                    <div className="w-full h-32 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg mb-4"></div>
                    <CardTitle className={isDark ? 'text-white' : 'text-gray-900'}>Método Avançado</CardTitle>
                    <CardDescription className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                      Técnicas avançadas e teoria musical completa
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-purple-500 mb-4">R$ 147,00</div>
                    <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                      Comprar Agora
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Aba Configurações */}
          <TabsContent value="configuracoes" className="space-y-6">
            <div className="max-w-2xl mx-auto space-y-6">
              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardHeader>
                  <CardTitle className={`${isDark ? 'text-white' : 'text-gray-900'} flex items-center gap-2`}>
                    <User className="w-5 h-5" />
                    Perfil do Usuário
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Nome</label>
                    <Input 
                      defaultValue="Aluno" 
                      className={isDark ? 'bg-gray-700/50 border-gray-600 text-white' : 'bg-gray-100 border-gray-300 text-gray-900'}
                    />
                  </div>
                  <div>
                    <label className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Email</label>
                    <Input 
                      defaultValue="notaaicliente1284@notaai.site" 
                      className={isDark ? 'bg-gray-700/50 border-gray-600 text-white' : 'bg-gray-100 border-gray-300 text-gray-900'}
                    />
                  </div>
                  <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                    Salvar Alterações
                  </Button>
                </CardContent>
              </Card>

              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardHeader>
                  <CardTitle className={`${isDark ? 'text-white' : 'text-gray-900'} flex items-center gap-2`}>
                    <Lock className="w-5 h-5" />
                    Segurança
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Nova Senha</label>
                    <Input 
                      type="password" 
                      placeholder="Digite nova senha"
                      className={isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500'}
                    />
                  </div>
                  <div>
                    <label className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Confirmar Nova Senha</label>
                    <Input 
                      type="password" 
                      placeholder="Confirme nova senha"
                      className={isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500'}
                    />
                  </div>
                  <Button variant="outline" className={isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}>
                    Alterar Senha
                  </Button>
                </CardContent>
              </Card>

              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardHeader>
                  <CardTitle className={`${isDark ? 'text-white' : 'text-gray-900'} flex items-center gap-2`}>
                    <Settings className="w-5 h-5" />
                    Preferências
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>Modo Escuro</span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsDark(!isDark)}
                      className={isDark ? 'border-gray-600 text-gray-300' : 'border-gray-300 text-gray-600'}
                    >
                      {isDark ? 'Ativado' : 'Desativado'}
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>Notificações</span>
                    <Button variant="outline" size="sm" className={isDark ? 'border-gray-600 text-gray-300' : 'border-gray-300 text-gray-600'}>
                      Ativado
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>Lembrar Login</span>
                    <Button variant="outline" size="sm" className={isDark ? 'border-gray-600 text-gray-300' : 'border-gray-300 text-gray-600'}>
                      Ativado
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardHeader>
                  <CardTitle className={`${isDark ? 'text-white' : 'text-gray-900'} flex items-center gap-2`}>
                    <HelpCircle className="w-5 h-5" />
                    Suporte
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}>
                    <HelpCircle className="w-4 h-4 mr-2" />
                    Central de Ajuda
                  </Button>
                  <Button variant="outline" className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}>
                    Contato via WhatsApp
                  </Button>
                  <Button variant="outline" className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}>
                    Enviar E-mail
                  </Button>
                </CardContent>
              </Card>

              <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
                <CardHeader>
                  <CardTitle className={`${isDark ? 'text-white' : 'text-gray-900'} flex items-center gap-2`}>
                    <FileText className="w-5 h-5" />
                    Legal
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}>
                    Termos de Uso
                  </Button>
                  <Button variant="outline" className={`w-full ${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}>
                    Política de Privacidade
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}