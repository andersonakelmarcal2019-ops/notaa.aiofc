'use client'

import { useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  ArrowLeft, 
  Play, 
  Download, 
  Heart, 
  Clock, 
  Star,
  Music,
  BookOpen,
  CheckCircle,
  User,
  Calendar
} from 'lucide-react'

export default function VideoAula() {
  const params = useParams()
  const router = useRouter()
  const [isFavorite, setIsFavorite] = useState(false)
  const [progress, setProgress] = useState(0)
  const [isCompleted, setIsCompleted] = useState(false)

  // Mock data - em produção viria da API
  const musica = {
    id: params.id,
    nome: "🎹 Imagine - John Lennon",
    categoria: "Pop",
    dificuldade: "Iniciante",
    duracao: "15:30",
    descricao: "Aprenda a tocar 'Imagine' de John Lennon no piano. Uma das músicas mais icônicas da história, com acordes simples e melodia envolvente. Nesta aula, vamos trabalhar a técnica básica, leitura de partitura e expressão musical.",
    professor: "João Silva",
    dataAula: "15/11/2024",
    visualizacoes: 1234,
    avaliacao: 4.8,
    totalAulas: 12,
    aulaAtual: 1
  }

  const getDificuldadeColor = (dificuldade: string) => {
    switch (dificuldade) {
      case 'Iniciante': return 'bg-green-500'
      case 'Intermediário': return 'bg-yellow-500'
      case 'Avançado': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const handleProgressComplete = () => {
    setProgress(100)
    setIsCompleted(true)
  }

  const handleDownloadPDF = () => {
    // Simulação de download
    const link = document.createElement('a')
    link.href = '/partitura.pdf' // Mock URL
    link.download = `${musica.nome.replace(/[^\w\s]/gi, '')}.pdf`
    link.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Header */}
      <header className="bg-gray-800/90 backdrop-blur-md border-b border-gray-700 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => router.back()}
                className="text-gray-400 hover:text-white"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
              
              <div className="flex items-center gap-3">
                <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg">
                  <Music className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-white">{musica.nome}</h1>
                  <p className="text-xs text-gray-400">Aula de Piano</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsFavorite(!isFavorite)}
                className="text-gray-400 hover:text-yellow-500"
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
              </Button>
              
              {isCompleted && (
                <Badge className="bg-green-500 text-white">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Concluído
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Video Player Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Player */}
            <Card className="bg-gray-800/50 border-gray-700 overflow-hidden">
              <div className="aspect-video bg-black flex items-center justify-center">
                <div className="text-center">
                  <Play className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400 mb-4">Player de vídeo</p>
                  <p className="text-sm text-gray-500">O vídeo será adicionado aqui</p>
                </div>
              </div>
              
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <Button className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                      <Play className="w-4 h-4 mr-2" />
                      Assistir Aula
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={handleDownloadPDF}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Baixar Partitura
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-400">
                    <Clock className="w-4 h-4" />
                    <span>{musica.duracao}</span>
                  </div>
                </div>
                
                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Seu progresso</span>
                    <span className="text-gray-400">{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5" />
                  Sobre a Aula
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 leading-relaxed mb-4">
                  {musica.descricao}
                </p>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-500">{musica.duracao}</div>
                    <div className="text-sm text-gray-400">Duração</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{musica.dificuldade}</div>
                    <div className="text-sm text-gray-400">Nível</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-500">{musica.visualizacoes}</div>
                    <div className="text-sm text-gray-400">Visualizações</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-500">{musica.avaliacao}</div>
                    <div className="text-sm text-gray-400">Avaliação</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Lesson Content */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Conteúdo da Aula</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
                    <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      1
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Introdução à música</h4>
                      <p className="text-sm text-gray-400">História e contexto de "Imagine"</p>
                    </div>
                    <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                      Assistir
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
                    <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      2
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Acordes básicos</h4>
                      <p className="text-sm text-gray-400">Aprenda os acordes principais</p>
                    </div>
                    <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                      Assistir
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
                    <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      3
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Melodia e ritmo</h4>
                      <p className="text-sm text-gray-400">Tocando a melodia principal</p>
                    </div>
                    <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                      Assistir
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-700/30 rounded-lg">
                    <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      4
                    </div>
                    <div className="flex-1">
                      <h4 className="text-white font-medium">Prática completa</h4>
                      <p className="text-sm text-gray-400">Juntando tudo com acompanhamento</p>
                    </div>
                    <Button size="sm" variant="outline" className="border-gray-600 text-gray-300">
                      Assistir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Course Info */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Informações do Curso</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <User className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-400">Professor</p>
                    <p className="text-white font-medium">{musica.professor}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-400">Data da aula</p>
                    <p className="text-white font-medium">{musica.dataAula}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Music className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-400">Categoria</p>
                    <p className="text-white font-medium">{musica.categoria}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Star className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-400">Avaliação</p>
                    <p className="text-white font-medium">{musica.avaliacao} / 5.0</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Difficulty Badge */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-4">
                <div className="text-center">
                  <Badge className={`text-white ${getDificuldadeColor(musica.dificuldade)} mb-2`}>
                    {musica.dificuldade}
                  </Badge>
                  <p className="text-sm text-gray-400">
                    {musica.dificuldade === 'Iniciante' && 'Perfeito para quem está começando'}
                    {musica.dificuldade === 'Intermediário' && 'Requer conhecimentos básicos'}
                    {musica.dificuldade === 'Avançado' && 'Para músicos experientes'}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                  <Play className="w-4 h-4 mr-2" />
                  Continuar Aula
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleDownloadPDF}
                  className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Partitura
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  <Star className="w-4 h-4 mr-2" />
                  Avaliar Aula
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Adicionar aos Favoritos
                </Button>
              </CardContent>
            </Card>

            {/* Progress Overview */}
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">Seu Progresso</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Aula {musica.aulaAtual} de {musica.totalAulas}</span>
                    <span className="text-gray-400">{Math.round((musica.aulaAtual / musica.totalAulas) * 100)}%</span>
                  </div>
                  <Progress value={(musica.aulaAtual / musica.totalAulas) * 100} className="h-2" />
                </div>
                
                <div className="text-center">
                  <p className="text-sm text-gray-400 mb-2">Próxima aula</p>
                  <p className="text-white font-medium">🎹 Yesterday - The Beatles</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}