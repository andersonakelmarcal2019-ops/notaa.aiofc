'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { useTheme } from '@/hooks/use-theme'
import { 
  Settings, 
  ShoppingBag, 
  Music, 
  Search, 
  Filter, 
  Star, 
  Download, 
  Play, 
  Moon, 
  Sun,
  HelpCircle,
  FileText,
  Heart,
  Clock,
  User,
  LogOut
} from 'lucide-react'

export default function AdminHome() {
  const [isDark, setIsDark] = useTheme()

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-gray-100 via-gray-50 to-gray-100'}`}>
      {/* Header */}
      <header className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-200'} backdrop-blur-md border-b sticky top-0 z-50`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Painel Administrativo</h1>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Gerenciamento de Conteúdo</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button
                onClick={() => window.location.href = '/admin/videos'}
                variant="outline"
                size="sm"
                className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}
              >
                <Settings className="w-4 h-4 mr-2" />
                Gerenciar Vídeos
              </Button>
              
              <Button
                onClick={() => window.location.href = '/admin/videos'}
                variant="outline"
                size="sm"
                className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}
              >
                Upload Vídeos
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="text-center mb-8">
          <h2 className={`text-3xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>🎹 Sistema de Gerenciamento de Vídeos</h2>
          <p className={`text-lg ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Gerencie todos os 200 vídeos tutoriais de forma simples e organizada
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Estatísticas */}
          <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
            <CardHeader>
              <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                📊 Estatísticas
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-500">200</div>
                  <div className="text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Total de Vídeos</div>
                </div>
                <div className="text-2xl font-bold text-green-500">
                    {videos.filter(v => v.categoria === 'Iniciante').length}
                  </div>
                  <div className="text-2xl font-bold text-blue-500">
                    {videos.filter(v => v.categoria === 'Intermediário').length}
                  </div>
                  <div className="text-2xl font-bold text-red-500">
                    {videos.filter(v => v.categoria === 'Clássico').length}
                  </div>
                  <div className="text-2xl font-bold text-purple-500">
                    {videos.filter(v => v.categoria === 'Brasileiras').length}
                  </div>
                </div>
              </div>
            </Card>

          {/* Vídeos Recentes */}
          <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
            <CardHeader>
              <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                📅 Vídeos Recentes
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <p className={`text-lg ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  {videos.slice(0, 5).map(video => (
                    <Card key={video.id} className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} hover:shadow-lg transition-all duration-200`}>
                      <CardHeader className="p-4">
                        <div className="aspect-video bg-black rounded-lg overflow-hidden mb-4">
                          <img 
                            src={video.thumbnail} 
                            alt={video.titulo}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          <h4 className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                            {video.titulo}
                          </h4>
                          <div className="flex items-center gap-2 mb-3">
                            <Badge className={`text-xs ${getNivelColor(video.nivel)} text-white`}>
                              {video.nivel}
                            </Badge>
                            </Badge>
                            <Badge variant="secondary" className={`text-xs ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}>
                              {video.categoria}
                            </Badge>
                          </div>
                          
                          <div className="text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                            {video.descricao}
                          </div>
                          
                          <div className="flex items-center gap-4 mt-4">
                            <Button
                              size="sm"
                              onClick={() => window.open(video.videoUrl, '_blank')}
                              className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-xs"
                            >
                              <Play className="w-3 h-3 mr-1" />
                              Ver Vídeo
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700 text-gray-600 hover:bg-gray-100' text-xs`}
                            >
                              <Download className="w-3 h-3 mr-1" />
                            Baixar Partitura
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </Card>
        </div>
      </main>
    </div>
  )
}