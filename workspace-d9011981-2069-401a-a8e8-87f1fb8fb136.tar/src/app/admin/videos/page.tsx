'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useTheme } from '@/hooks/use-theme'
import { 
  Settings, 
  ShoppingBag, 
  Music, 
  Search, 
  Filter, 
  Star, 
  Download, 
  Play, 
  Moon, 
  Sun,
  HelpCircle,
  FileText,
  Heart,
  Clock,
  User,
  LogOut,
  Upload,
  Save,
  Trash2,
  Eye,
  EyeOff,
  ChevronDown,
  ChevronUp,
  Edit,
  Plus,
  X,
  Check
} from 'lucide-react'

// Dados dos vídeos (mock - em produção viria da API)
const videosData = [
  {
    id: 1,
    nome: "🔹 Someone Like You – Adele",
    categoria: "Iniciante",
    videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    duracao: "4:32",
    descricao: "Aprenda a tocar este clássico da Adele com acordes simples e ritmo suave. Perfeito para iniciantes que querem começar a tocar piano.",
    nivel: "Iniciante",
    canal: "Piano Tutoriais BR",
    thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/hqdefault.jpg",
    tags: ["adele", "piano", "tutorial", "iniciante"]
  },
  {
    id: 2,
    nome: "🔹 All of Me – John Legend",
    categoria: "Iniciante",
    videoUrl: "https://www.youtube.com/watch?v=YQ_mVjP7j8",
    duracao: "3:45",
    descricao: "Uma das músicas mais bonitas de todos os tempos. Aprenda a tocar com feeling e emoção. Ideal para trabalhar expressividade no piano.",
    nivel: "Iniciante",
    canal: "Piano Lessons",
    thumbnail: "https://img.youtube.com/vi/YQ_mVjP7j8/hqdefault.jpg",
    tags: ["john legend", "piano", "tutorial", "iniciante"]
  },
  {
    id: 3,
    nome: "🎼 Für Elise – Beethoven",
    categoria: "Clássico",
    videoUrl: "https://www.youtube.com/watch?v=k1Qp6gKj8",
    duracao: "5:12",
    descricao: "Uma das peças mais famosas de Beethoven. Tutorial detalhado para iniciantes que querem explorar música clássica.",
    nivel: "Intermediário",
    canal: "Classical Piano Tutorials",
    thumbnail: "https://img.youtube.com/vi/k1Qp6gKj8/hqdefault.jpg",
    tags: ["beethoven", "classical", "piano", "tutorial", "intermediário"]
  }
]

// Função para buscar tutoriais no YouTube
async function searchYouTubeTutorials(query: string, maxResults: number = 5) {
  try {
    const apiKey = process.env.YOUTUBE_API_KEY || 'YOUR_API_KEY'
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&maxResults=${maxResults}&type=video&key=${apiKey}`
    )
    const data = await response.json()
    
    return data.items?.map((item: any) => ({
      id: item.id?.videoId,
      titulo: item.snippet?.title,
      descricao: item.snippet?.description,
      thumbnail: item.snippet?.thumbnails?.default?.url,
      videoUrl: `https://www.youtube.com/watch?v=${item.id?.videoId}`,
      canal: item.snippet?.channelTitle,
      duracao: item.contentDetails?.duration,
      visualizacoes: item.statistics?.viewCount?.toString() || '0'
    })) || []
  } catch (error) {
    console.error('Erro ao buscar tutoriais:', error)
    return []
  }
}

// Componente de vídeo aula aprimorado
function VideoAula({ video, isDark }: { video: typeof videosData[0]; isDark: boolean }) {
  const [isFavorite, setIsFavorite] = useState(false)
  const [showTranscript, setShowTranscript] = useState(false)
  const [rating, setRating] = useState(0)
  const [notes, setNotes] = useState('')
  const [progress, setProgress] = useState(0)

  const getNivelColor = (nivel: string) => {
    switch (nivel) {
      case 'Iniciante': return 'bg-green-500'
      case 'Intermediário': return 'bg-yellow-500'
      case 'Avançado': return 'bg-red-500'
      default: return 'bg-blue-500'
    }
  }

  const handleFavorite = () => {
    setIsFavorite(!isFavorite)
  }

  const handleRating = (value: number) => {
    setRating(value)
  }

  const handleProgress = (value: number) => {
    setProgress(value)
  }

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-gray-100 via-gray-50 to-gray-100'}`}>
      {/* Header */}
      <header className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-200'} backdrop-blur-md border-b sticky top-0 z-50`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>{video.titulo}</h1>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Aula de Piano</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleFavorite}
                className={`${isDark ? 'text-gray-400 hover:text-yellow-500' : 'text-gray-600 hover:text-yellow-500'}`}
              >
                <Heart className={`w-4 h-4 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}
              >
                <Download className="w-4 h-4 mr-2" />
                Baixar Partitura
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Player de Vídeo */}
          <div className="lg:col-span-2">
            <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-200'} overflow-hidden`}>
              <CardContent className="p-0">
                <div className="relative aspect-video bg-black">
                  {/* Player do YouTube - substituído por iframe */}
                  <iframe
                    src={video.videoUrl}
                    className="w-full h-full"
                    allowFullScreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allow="web-share"
                  />
                  
                  {/* Overlay de informações */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="text-white text-sm">
                          <div className="font-semibold">{video.titulo}</div>
                          <div className="text-xs opacity-75">{video.canal}</div>
                        </div>
                      </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                          {video.duracao} • {video.visualizacoes} visualizações
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

          {/* Informações da Aula */}
          <div className="lg:col-span-1 space-y-6">
            <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-200'}`}>
              <CardHeader>
                <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  📚 Informações da Aula
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Descrição:</span>
                    <Badge className={`ml-2 ${getNivelColor(video.nivel)} text-white`}>
                      {video.nivel}
                    </Badge>
                  </div>
                  <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                    {video.descricao}
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Duração:</span>
                    <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                      {video.duracao}
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Professor:</span>
                    <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                      {video.canal}
                    </span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Canal:</span>
                    <a 
                      href={video.videoUrl}
                      target="_blank"
                      className={`text-sm ${isDark ? 'text-yellow-500 hover:text-yellow-400' : 'text-yellow-600'}`}
                    >
                      {video.canal}
                    </a>
                  </div>
                </div>
              </div>
              </CardContent>
            </Card>

            {/* Progresso e Avaliação */}
            <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-200'}`}>
              <CardHeader>
                <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  📊 Seu Progresso
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Progresso:</span>
                    <div className="flex-1">
                      <Progress value={progress} className="w-full" />
                    </div>
                    <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{progress}%</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Avaliação:</span>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Button
                          key={star}
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRating(star)}
                          className={`${rating >= star ? 'text-yellow-500' : isDark ? 'text-gray-400 hover:text-yellow-500' : 'text-gray-600 hover:text-yellow-700'}`}
                        >
                          <Star className={`w-4 h-4 ${rating >= star ? 'fill-yellow-500 text-yellow-500' : ''}`} />
                        </Button>
                      ))}
                    </div>
                    <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                      {rating.toFixed(1)} / 5.0
                    </span>
                  </div>
                </div>
              </div>
              </CardContent>
            </Card>

            {/* Anotações */}
            <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-200'}`}>
              <CardHeader>
                <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                  📝 Anotações
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-sm font-medium ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Suas anotações:</span>
                  </div>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Adicione suas anotações aqui..."
                    className={`w-full h-32 p-3 ${isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500'}`}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

// Componente de upload de vídeos
function VideoUpload({ onUpload, isDark }: { onUpload: (videos: any[]) => void; isDark: boolean }) {
  const [isDragging, setIsDragging] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadStatus, setUploadStatus] = useState('')

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const handleFileUpload = async (file: File) => {
    setUploadStatus('Processando...')
    setUploadProgress(25)
    
    const formData = new FormData()
    formData.append('video', file)
    
    try {
      // Simulação de upload - em produção seria para sua API
      await new Promise(resolve => setTimeout(resolve, 2000))
      
      setUploadStatus('Sucesso!')
      setUploadProgress(100)
      
      // Atualizar dados mock
      const newVideo = {
        id: Date.now(),
        nome: file.name.replace(/\.[^/.]+$/, ''),
        videoUrl: `https://example.com/${file.name}`,
        categoria: 'Iniciante',
        descricao: `Upload do vídeo: ${file.name}`,
        nivel: 'Iniciante',
        canal: 'Seu Canal',
        thumbnail: 'https://via.placeholder.com/thumb.jpg',
        tags: ['upload', 'tutorial']
      }
      
      onUpload([newVideo])
    } catch (error) {
      console.error('Erro no upload:', error)
      setUploadStatus('Erro no upload')
      setUploadProgress(0)
    }
  }

  return (
    <Card className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'}`}>
      <CardHeader>
        <CardTitle className={`text-lg font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>
          📤 Upload de Vídeos
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div
          className={`border-2 border-dashed ${isDragging ? 'border-yellow-500' : isDark ? 'border-gray-600' : 'border-gray-300'} rounded-lg p-8 text-center`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Upload className="w-8 h-8 text-gray-400 mb-4" />
          <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
            Arraste vídeos aqui ou clique para selecionar
          </p>
          <input
            type="file"
            multiple
            accept="video/*"
            className="hidden"
            onChange={(e) => {
              if (e.target.files.length > 0) {
                handleFileUpload(e.target.files[0])
              }
            }}
          />
        </div>
        
        {uploadProgress > 0 && (
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              style={{ width: `${uploadProgress}%` }}
              className="bg-yellow-500 h-full transition-all duration-300"
            ></div>
          </div>
        )}
        
        <div className="text-center space-y-2">
          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            {uploadStatus}
          </p>
          {uploadProgress > 0 && uploadProgress < 100 && (
            <Button 
              onClick={() => setUploadProgress(0)}
              variant="outline"
              className={`${isDark ? 'border-gray-600 text-gray-300 hover:bg-gray-700' : 'border-gray-300 text-gray-600 hover:bg-gray-100'}`}
            >
              Cancelar
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default function VideoManager() {
  const [videos, setVideos] = useState(videosData)
  const [isDark, setIsDark] = useTheme()
  const [showUpload, setShowUpload] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')

  const handleUpload = (uploadedVideos: any[]) => {
    setVideos([...videos, ...uploadedVideos])
    setShowUpload(false)
  }

  const filteredVideos = videos.filter(video =>
    video.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    video.descricao.toLowerCase().includes(searchTerm.toLowerCase()) ||
    video.canal.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900' : 'bg-gradient-to-br from-gray-100 via-gray-50 to-gray-100'}`}>
      {/* Header */}
      <header className={`${isDark ? 'bg-gray-800/90 border-gray-700' : 'bg-white/90 border-gray-200'} backdrop-blur-md border-b sticky top-0 z-50`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Gerenciador de Vídeos</h1>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Sistema de gerenciamento de vídeos tutoriais</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button
                onClick={() => setShowUpload(!showUpload)}
                variant={showUpload ? "default" : "outline"}
                className={showUpload ? "bg-yellow-500 hover:bg-yellow-600 text-white" : "border-gray-600 text-gray-300 hover:bg-gray-700"}
              >
                <Upload className="w-4 h-4 mr-2" />
                {showUpload ? 'Fechar Upload' : 'Fazer Upload'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        {showUpload ? (
          <VideoUpload onUpload={handleUpload} isDark={isDark} />
        ) : (
          <div className="space-y-6">
            {/* Busca */}
            <div className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} rounded-lg p-4`}>
              <div className="relative">
                <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'} w-4 h-4`} />
                <Input
                  placeholder="Buscar vídeos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`pl-10 w-full ${isDark ? 'bg-gray-700/50 border-gray-600 text-white placeholder-gray-400' : 'bg-gray-100 border-gray-300 text-gray-900 placeholder-gray-500'}`}
                />
              </div>
            </div>

            {/* Lista de Vídeos */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos.map((video, index) => (
                <Card key={video.id} className={`${isDark ? 'bg-gray-800/50 border-gray-700' : 'bg-white/50 border-gray-300'} hover:shadow-lg transition-all duration-200`}>
                  <CardHeader className="p-4">
                    <div className="aspect-video bg-black rounded-lg overflow-hidden mb-4">
                      <img 
                        src={video.thumbnail} 
                        alt={video.titulo}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <h3 className={`font-semibold text-lg ${isDark ? 'text-white' : 'text-gray-900'} mb-2`}>
                        {video.titulo}
                      </h3>
                      
                      <div className="flex items-center gap-2 mb-3">
                        <Badge className={`text-xs ${getNivelColor(video.nivel)} text-white`}>
                          {video.nivel}
                        </Badge>
                        <Badge variant="secondary" className={`text-xs ${isDark ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-700'}`}>
                          {video.categoria}
                        </Badge>
                      </div>
                      
                      <div className="text-sm ${isDark ? 'text-gray-400' : 'text-gray-600' mb-3 line-clamp-2">
                        {video.descricao}
                      </div>
                      
                      <div className="flex items-center gap-4 mt-4">
                        <Button
                          size="sm"
                          onClick={() => window.open(video.videoUrl, '_blank')}
                          className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white text-xs"
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Assistir
                        </Button>
                        <Button
                          size="sm"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700 text-xs"
                        >
                          <Download className="w-3 h-3 mr-1" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  )
}